"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Zap,
  Droplets,
  Flame,
  Wifi,
  CreditCard,
  BarChart3,
  Bell,
  Settings,
  WifiOff,
  AlertTriangle,
  TrendingUp,
  Home,
} from "lucide-react"

export default function UtiliHubMalaysia() {
  const [isOffline, setIsOffline] = useState(false)
  const [language, setLanguage] = useState<"ms" | "en">("ms")

  const text = {
    ms: {
      title: "UtiliHub Malaysia",
      tagline: "Memberdayakan Rakyat Malaysia dengan Kawalan Utiliti yang Boleh Dipercayai dan Mudah Diakses",
      dashboard: "Papan Pemuka",
      electricity: "Elektrik",
      water: "Air",
      gas: "Gas",
      internet: "Internet",
      thisMonth: "Bulan Ini",
      payBill: "Bayar Bil",
      viewUsage: "Lihat Penggunaan",
      setAlerts: "Tetapkan Amaran",
      quickActions: "Tindakan Pantas",
      recentAlerts: "Amaran Terkini",
      highUsage: "Penggunaan Tinggi Dijangka",
      billDue: "Bil Perlu Dibayar Esok",
      offline: "Luar Talian",
      syncWhenOnline: "Segerak Apabila Dalam Talian",
      home: "Utama",
      usage: "Penggunaan",
      payments: "Pembayaran",
      settings: "Tetapan",
    },
    en: {
      title: "UtiliHub Malaysia",
      tagline: "Empowering Malaysians with Reliable, Accessible Utility Control Anytime, Anywhere",
      dashboard: "Dashboard",
      electricity: "Electricity",
      water: "Water",
      gas: "Gas",
      internet: "Internet",
      thisMonth: "This Month",
      payBill: "Pay Bill",
      viewUsage: "View Usage",
      setAlerts: "Set Alerts",
      quickActions: "Quick Actions",
      recentAlerts: "Recent Alerts",
      highUsage: "High Usage Predicted",
      billDue: "Bill Due Tomorrow",
      offline: "Offline",
      syncWhenOnline: "Sync When Online",
      home: "Home",
      usage: "Usage",
      payments: "Payments",
      settings: "Settings",
    },
  }

  const t = text[language]

  const utilities = [
    {
      name: t.electricity,
      icon: Zap,
      usage: "120 kWh",
      color: "bg-yellow-500",
      progress: 65,
      cost: "RM 85.50",
    },
    {
      name: t.water,
      icon: Droplets,
      usage: "15 m³",
      color: "bg-blue-500",
      progress: 45,
      cost: "RM 32.00",
    },
    {
      name: t.gas,
      icon: Flame,
      usage: "8 m³",
      color: "bg-orange-500",
      progress: 30,
      cost: "RM 28.75",
    },
    {
      name: t.internet,
      icon: Wifi,
      usage: "250 GB",
      color: "bg-purple-500",
      progress: 80,
      cost: "RM 89.00",
    },
  ]

  const alerts = [
    {
      title: t.highUsage,
      description: "Penggunaan elektrik mungkin melebihi 150 kWh minggu ini",
      icon: AlertTriangle,
      severity: "warning",
    },
    {
      title: t.billDue,
      description: "Bil air RM 32.00 perlu dibayar esok",
      icon: CreditCard,
      severity: "info",
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-primary text-primary-foreground p-4 shadow-lg">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold text-balance">{t.title}</h1>
            <p className="text-sm opacity-90 text-pretty">{t.tagline}</p>
          </div>
          <div className="flex items-center gap-2">
            {isOffline && (
              <Badge variant="secondary" className="bg-orange-500 text-white">
                <WifiOff className="w-3 h-3 mr-1" />
                {t.offline}
              </Badge>
            )}
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setLanguage(language === "ms" ? "en" : "ms")}
              className="text-primary-foreground hover:bg-primary-foreground/20"
            >
              {language === "ms" ? "EN" : "MS"}
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="p-4 pb-20">
        {/* Dashboard Title */}
        <div className="mb-6">
          <h2 className="text-2xl font-bold text-foreground mb-2">{t.dashboard}</h2>
        </div>

        {/* Utility Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          {utilities.map((utility, index) => (
            <Card key={index} className="border-border shadow-sm">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-3 text-lg">
                  <div className={`p-2 rounded-lg ${utility.color}`}>
                    <utility.icon className="w-5 h-5 text-white" />
                  </div>
                  <div className="flex-1">
                    <div className="font-semibold">{utility.name}</div>
                    <div className="text-sm text-muted-foreground">{t.thisMonth}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-lg">{utility.cost}</div>
                    <div className="text-sm text-muted-foreground">{utility.usage}</div>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Progress value={utility.progress} className="h-2" />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>0%</span>
                    <span>{utility.progress}%</span>
                    <span>100%</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Quick Actions */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-primary" />
              {t.quickActions}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-3">
              <Button variant="outline" className="flex flex-col gap-2 h-auto py-4 bg-transparent">
                <CreditCard className="w-6 h-6 text-primary" />
                <span className="text-xs text-center">{t.payBill}</span>
              </Button>
              <Button variant="outline" className="flex flex-col gap-2 h-auto py-4 bg-transparent">
                <BarChart3 className="w-6 h-6 text-primary" />
                <span className="text-xs text-center">{t.viewUsage}</span>
              </Button>
              <Button variant="outline" className="flex flex-col gap-2 h-auto py-4 bg-transparent">
                <Bell className="w-6 h-6 text-primary" />
                <span className="text-xs text-center">{t.setAlerts}</span>
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Recent Alerts */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bell className="w-5 h-5 text-primary" />
              {t.recentAlerts}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {alerts.map((alert, index) => (
                <div key={index} className="flex items-start gap-3 p-3 rounded-lg bg-muted/50">
                  <div className={`p-2 rounded-lg ${alert.severity === "warning" ? "bg-orange-500" : "bg-blue-500"}`}>
                    <alert.icon className="w-4 h-4 text-white" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-sm">{alert.title}</h4>
                    <p className="text-xs text-muted-foreground mt-1">{alert.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Offline Mode Indicator */}
        {isOffline && (
          <Card className="mt-6 border-orange-200 bg-orange-50">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <WifiOff className="w-5 h-5 text-orange-600" />
                <div className="flex-1">
                  <p className="font-semibold text-orange-800">{t.offline}</p>
                  <p className="text-sm text-orange-600">Data akan disegerakkan apabila sambungan dipulihkan</p>
                </div>
                <Button size="sm" variant="outline" className="border-orange-300 text-orange-700 bg-transparent">
                  {t.syncWhenOnline}
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-card border-t border-border">
        <div className="grid grid-cols-4 gap-1">
          <Button variant="ghost" className="flex flex-col gap-1 py-3 h-auto rounded-none bg-primary/10 text-primary">
            <Home className="w-5 h-5" />
            <span className="text-xs">{t.home}</span>
          </Button>
          <Button variant="ghost" className="flex flex-col gap-1 py-3 h-auto rounded-none">
            <BarChart3 className="w-5 h-5" />
            <span className="text-xs">{t.usage}</span>
          </Button>
          <Button variant="ghost" className="flex flex-col gap-1 py-3 h-auto rounded-none">
            <CreditCard className="w-5 h-5" />
            <span className="text-xs">{t.payments}</span>
          </Button>
          <Button variant="ghost" className="flex flex-col gap-1 py-3 h-auto rounded-none">
            <Settings className="w-5 h-5" />
            <span className="text-xs">{t.settings}</span>
          </Button>
        </div>
      </nav>
    </div>
  )
}
