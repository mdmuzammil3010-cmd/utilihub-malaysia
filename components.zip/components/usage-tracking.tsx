"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"
import { TrendingUp, TrendingDown, Zap, Droplets } from "lucide-react"

const usageData = [
  { day: "Sen", electricity: 4.2, water: 0.8 },
  { day: "Sel", electricity: 3.8, water: 0.9 },
  { day: "Rab", electricity: 4.5, water: 0.7 },
  { day: "Kha", electricity: 5.1, water: 1.1 },
  { day: "Jum", electricity: 4.8, water: 0.9 },
  { day: "Sab", electricity: 6.2, water: 1.3 },
  { day: "Ahd", electricity: 5.5, water: 1.2 },
]

export function UsageTracking() {
  return (
    <div className="space-y-6">
      {/* Usage Overview */}
      <div className="grid grid-cols-2 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-sm">
              <Zap className="w-4 h-4 text-yellow-500" />
              Elektrik Minggu Ini
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">32.1 kWh</div>
            <div className="flex items-center gap-1 text-sm">
              <TrendingUp className="w-3 h-3 text-green-500" />
              <span className="text-green-600">+12%</span>
              <span className="text-muted-foreground">dari minggu lepas</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-sm">
              <Droplets className="w-4 h-4 text-blue-500" />
              Air Minggu Ini
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">6.9 m³</div>
            <div className="flex items-center gap-1 text-sm">
              <TrendingDown className="w-3 h-3 text-red-500" />
              <span className="text-red-600">-5%</span>
              <span className="text-muted-foreground">dari minggu lepas</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Usage Chart */}
      <Card>
        <CardHeader>
          <CardTitle>Penggunaan Harian</CardTitle>
          <div className="flex gap-2">
            <Badge variant="outline" className="text-yellow-600 border-yellow-200">
              <Zap className="w-3 h-3 mr-1" />
              Elektrik
            </Badge>
            <Badge variant="outline" className="text-blue-600 border-blue-200">
              <Droplets className="w-3 h-3 mr-1" />
              Air
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={usageData}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis dataKey="day" className="text-xs" />
                <YAxis className="text-xs" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "8px",
                  }}
                />
                <Line
                  type="monotone"
                  dataKey="electricity"
                  stroke="hsl(var(--chart-1))"
                  strokeWidth={2}
                  dot={{ fill: "hsl(var(--chart-1))", strokeWidth: 2 }}
                />
                <Line
                  type="monotone"
                  dataKey="water"
                  stroke="hsl(var(--chart-2))"
                  strokeWidth={2}
                  dot={{ fill: "hsl(var(--chart-2))", strokeWidth: 2 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Predictive Alerts */}
      <Card className="border-orange-200 bg-orange-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-orange-800">
            <TrendingUp className="w-5 h-5" />
            Ramalan AI
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-orange-700 mb-3">
            Berdasarkan corak penggunaan, penggunaan elektrik anda mungkin meningkat 15% minggu depan.
          </p>
          <Button size="sm" variant="outline" className="border-orange-300 text-orange-700 bg-transparent">
            Lihat Cadangan Penjimatan
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
