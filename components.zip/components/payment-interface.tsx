"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { CreditCard, Smartphone, Building2, Shield, CheckCircle, Fingerprint } from "lucide-react"

export function PaymentInterface() {
  const [selectedBill, setSelectedBill] = useState<string | null>(null)
  const [paymentMethod, setPaymentMethod] = useState<string | null>(null)

  const bills = [
    {
      id: "electricity",
      name: "Bil Elektrik",
      amount: "RM 85.50",
      dueDate: "15 Jan 2025",
      status: "due",
      icon: "⚡",
    },
    {
      id: "water",
      name: "Bil Air",
      amount: "RM 32.00",
      dueDate: "18 Jan 2025",
      status: "upcoming",
      icon: "💧",
    },
    {
      id: "gas",
      name: "Bil Gas",
      amount: "RM 28.75",
      dueDate: "20 Jan 2025",
      status: "upcoming",
      icon: "🔥",
    },
  ]

  const paymentMethods = [
    {
      id: "maybank",
      name: "Maybank ****1234",
      type: "Bank Card",
      icon: CreditCard,
    },
    {
      id: "grabpay",
      name: "GrabPay",
      type: "E-Wallet",
      icon: Smartphone,
    },
    {
      id: "cimb",
      name: "CIMB ****5678",
      type: "Bank Card",
      icon: Building2,
    },
  ]

  return (
    <div className="space-y-6">
      {/* Outstanding Bills */}
      <Card>
        <CardHeader>
          <CardTitle>Bil Tertunggak</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {bills.map((bill) => (
            <div
              key={bill.id}
              className={`p-4 rounded-lg border cursor-pointer transition-colors ${
                selectedBill === bill.id ? "border-primary bg-primary/5" : "border-border hover:bg-muted/50"
              }`}
              onClick={() => setSelectedBill(bill.id)}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{bill.icon}</span>
                  <div>
                    <h4 className="font-semibold">{bill.name}</h4>
                    <p className="text-sm text-muted-foreground">Tarikh akhir: {bill.dueDate}</p>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-lg">{bill.amount}</div>
                  <Badge variant={bill.status === "due" ? "destructive" : "secondary"} className="text-xs">
                    {bill.status === "due" ? "Perlu Dibayar" : "Akan Datang"}
                  </Badge>
                </div>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Payment Methods */}
      {selectedBill && (
        <Card>
          <CardHeader>
            <CardTitle>Pilih Kaedah Pembayaran</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {paymentMethods.map((method) => (
              <div
                key={method.id}
                className={`p-4 rounded-lg border cursor-pointer transition-colors ${
                  paymentMethod === method.id ? "border-primary bg-primary/5" : "border-border hover:bg-muted/50"
                }`}
                onClick={() => setPaymentMethod(method.id)}
              >
                <div className="flex items-center gap-3">
                  <method.icon className="w-6 h-6 text-primary" />
                  <div>
                    <h4 className="font-semibold">{method.name}</h4>
                    <p className="text-sm text-muted-foreground">{method.type}</p>
                  </div>
                  {paymentMethod === method.id && <CheckCircle className="w-5 h-5 text-primary ml-auto" />}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Payment Summary */}
      {selectedBill && paymentMethod && (
        <Card>
          <CardHeader>
            <CardTitle>Ringkasan Pembayaran</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between">
                <span>Bil:</span>
                <span>{bills.find((b) => b.id === selectedBill)?.name}</span>
              </div>
              <div className="flex justify-between">
                <span>Jumlah:</span>
                <span className="font-bold">{bills.find((b) => b.id === selectedBill)?.amount}</span>
              </div>
              <div className="flex justify-between">
                <span>Kaedah Pembayaran:</span>
                <span>{paymentMethods.find((p) => p.id === paymentMethod)?.name}</span>
              </div>
            </div>

            <Separator />

            <div className="flex justify-between text-lg font-bold">
              <span>Jumlah Keseluruhan:</span>
              <span className="text-primary">{bills.find((b) => b.id === selectedBill)?.amount}</span>
            </div>

            <Button className="w-full" size="lg">
              <div className="flex items-center gap-2">
                <Fingerprint className="w-5 h-5" />
                Bayar Sekarang
              </div>
            </Button>

            <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
              <Shield className="w-4 h-4" />
              <span>Dilindungi dengan keselamatan biometrik</span>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
